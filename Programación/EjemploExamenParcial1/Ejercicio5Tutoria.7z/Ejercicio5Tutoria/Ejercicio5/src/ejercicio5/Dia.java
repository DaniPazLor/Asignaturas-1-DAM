package ejercicio5;

/**
 *
 * @author Jose Ignacio
 */

public class Dia {
    
    private String dia;
    
    Dia (String nombre){
        
        this.dia = nombre;
        
    }
    
    public String getDia(){
        
        return this.dia;
        
    }
     
    public void setDia(String dia){
        
        this.dia = dia;
        
    }
    
}